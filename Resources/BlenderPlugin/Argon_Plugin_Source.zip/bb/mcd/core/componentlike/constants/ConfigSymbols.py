
class ApplyObjectSymbols:
    
    @staticmethod
    def ArgonThisObject():
        return "__ARGON_THIS_OBJECT__"