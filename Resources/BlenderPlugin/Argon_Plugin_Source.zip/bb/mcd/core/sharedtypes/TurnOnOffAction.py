
TurnOnOffAction = (
    ('DoNothing', 'Do Nothing', 'Don\'t do anything'),
    ('TurnOn', 'Turn On', 'Turn On'),
    ('TurnOff', 'Turn Off', 'Turn Off'),
)